const express = require("express");
const app = express();
//const pet = require("./routes/pet")
const db = require("./config/database");
var cors = require("cors");
app.use(cors());
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  next();
});
app.use(express.json());
app.use(express.urlencoded({ extended: false, limit: "20mb" }));
app.get("/", (req, res) => {
  var sql = "SELECT * FROM pets";
  db.query(sql, function (err, data) {
    if (data.length > 1) {
      res.send(data);
    }
  });
});

module.exports = app;
